vjo.ctype('com.ebay.test.WithTest')
.props({
        //>public void func1() 
        func1 : function(){
                var 
        },

        test
})
.protos({

})
.endType();
