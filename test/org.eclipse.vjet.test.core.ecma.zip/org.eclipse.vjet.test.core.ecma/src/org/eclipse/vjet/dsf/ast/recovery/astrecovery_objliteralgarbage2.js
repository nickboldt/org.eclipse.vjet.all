foo({
	var x = 10;
})


