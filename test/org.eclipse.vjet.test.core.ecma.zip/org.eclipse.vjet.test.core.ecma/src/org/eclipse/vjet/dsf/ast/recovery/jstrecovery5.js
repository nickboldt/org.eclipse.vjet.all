vjo.ctype('aa.sytyperefs.AEx') //< public
.needs('aa.sytyperefs.A')
.props({
	main: function(args) { //< public void main(String[]) {
		var A = this.vj$.A ; //< Type::A
		if (A.
	}
})
.endType();
