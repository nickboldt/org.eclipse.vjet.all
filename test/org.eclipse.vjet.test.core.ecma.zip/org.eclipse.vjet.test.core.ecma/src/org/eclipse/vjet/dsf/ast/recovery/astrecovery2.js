foo(function(){
 foo(
}
