var x = [a,b,c]
var y = 10;