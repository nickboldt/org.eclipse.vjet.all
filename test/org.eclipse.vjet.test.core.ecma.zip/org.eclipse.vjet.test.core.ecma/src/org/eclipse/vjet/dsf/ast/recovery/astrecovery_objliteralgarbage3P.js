zoo.zat("test").foo({
	
})


