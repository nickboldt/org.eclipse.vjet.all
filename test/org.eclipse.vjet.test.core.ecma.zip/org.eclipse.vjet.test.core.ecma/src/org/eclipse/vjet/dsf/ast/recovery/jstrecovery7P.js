vjo.ctype('com.ebay.test.WithTest')
.props({
        //>public void func1() 
        func1 : function(){
                var $missing;
        },

        test : $missing
})
.protos({

})
.endType();
