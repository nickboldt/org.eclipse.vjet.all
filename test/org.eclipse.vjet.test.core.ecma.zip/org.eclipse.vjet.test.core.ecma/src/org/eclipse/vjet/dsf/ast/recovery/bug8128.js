vjo.ctype('a.b.c.AJava') //< public
.protos({
    //> public constructs(int jaxxx)
    constructs:function(jaxxx){
        this.this.
    }
})
.endType();
