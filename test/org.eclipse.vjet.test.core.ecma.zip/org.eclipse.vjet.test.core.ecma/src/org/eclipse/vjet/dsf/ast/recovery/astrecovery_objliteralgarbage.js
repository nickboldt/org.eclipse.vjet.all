var y = doIt({
	abcdef;
})

