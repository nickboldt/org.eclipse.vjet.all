var x = foo({
	zot
})


