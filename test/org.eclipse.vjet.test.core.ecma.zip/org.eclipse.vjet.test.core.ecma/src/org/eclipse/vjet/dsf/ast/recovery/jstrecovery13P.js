vjo.ctype('a.b.c.MyVjoType2') //< public
.props({

})
.protos({
    //> public void sb()
    sb:function(){
            if(this.$missing$){
            	
            }
    }
})
.inits(function(){
})
.endType();
