vjo.ctype('vjo.example.TestMe') //< public
.needs('org.eclipse.vjet.vjo.java.lang.System')
.inits(function(){
 foo(this.$missing2);
}).endType();