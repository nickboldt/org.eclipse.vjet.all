var x = foobar({foo : function () {
});