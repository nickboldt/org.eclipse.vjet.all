foo(function(){
 foo(
})
