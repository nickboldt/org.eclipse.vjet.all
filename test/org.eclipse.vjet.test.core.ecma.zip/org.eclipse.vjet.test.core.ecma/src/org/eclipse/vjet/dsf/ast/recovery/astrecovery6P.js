var x = [a,b,c,$missing$];
var y = 10;