var y = doIt({
	
})

