zoo.zat("test").foo({
	var x = 10;
})


