var x = foo({
	zot:$missing$
})


