function foo(){
	var x = doIt(this.$missing$)
}
