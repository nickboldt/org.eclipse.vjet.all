foo(function () {
  foo();
});
