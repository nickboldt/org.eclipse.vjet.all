vjo.ctype('aa.fmttime.Mathish') //< public
.props({
	a: Math.E, //< Number
	b: Math.LN2, //< double
	c: Math.LN10, //< Number
	main: function(args) { //< public void main(String[])
		vjo.sysout.println(this.$missing);
		Math.round(this.$missing);
		this.o(Math.round(this.$missing);
	}
})
.endType();