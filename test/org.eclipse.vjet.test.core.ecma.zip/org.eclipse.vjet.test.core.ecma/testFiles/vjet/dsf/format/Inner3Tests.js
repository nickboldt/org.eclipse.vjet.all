vjo.ctype("vjet.dsf.format.Inner3Tests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTest")
.protos({

test: function(){

var obj = {toString: function() {return new Object();}}

}

}).endType();
