vjo.ctype("vjet.dsf.format.InnerTests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTest")
.protos({

//> public void test()
test: function() {

function FuncInside() {
}

}

})
.endType();
