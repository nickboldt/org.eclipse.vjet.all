vjo.ctype("vjet.dsf.format.Parens2Tests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTest")
.protos({

test:function(){

this.TestCase( "",   "",   false,  Boolean( void(0) ) );

}


})
.endType();
