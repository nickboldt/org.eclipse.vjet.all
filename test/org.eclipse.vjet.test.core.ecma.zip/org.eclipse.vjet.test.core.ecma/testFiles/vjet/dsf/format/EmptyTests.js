vjo.ctype("vjet.dsf.format.EmptyTests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTest")
.protos({
}).endType()
