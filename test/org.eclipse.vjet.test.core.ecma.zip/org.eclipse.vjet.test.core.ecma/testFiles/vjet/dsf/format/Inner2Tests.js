vjo.ctype("vjet.dsf.format.Inner2Tests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTest")
.protos({

test: function(){
var x = function f(){
return "inner";
};
}

}).endType()

