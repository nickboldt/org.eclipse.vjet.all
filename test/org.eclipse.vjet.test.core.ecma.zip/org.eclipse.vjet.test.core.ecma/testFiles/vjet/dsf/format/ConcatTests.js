vjo.ctype("vjet.dsf.format.ConcatTests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTestEcma3")
.protos({

test: function() {

var foo = "hello" + " goodbye";

}

})
.endType();




