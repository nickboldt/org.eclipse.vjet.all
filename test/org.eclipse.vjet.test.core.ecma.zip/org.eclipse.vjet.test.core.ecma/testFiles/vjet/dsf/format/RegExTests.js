vjo.ctype("vjet.dsf.format.RegExTests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTestEcma3")
.protos({

test: function() {

before = "before";
re= /x/,re.lastIndex = 1
after = "after";

}

})
.endType();

