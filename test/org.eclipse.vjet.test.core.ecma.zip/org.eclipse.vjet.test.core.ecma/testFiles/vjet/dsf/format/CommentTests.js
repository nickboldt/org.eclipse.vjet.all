vjo.ctype("vjet.dsf.format.CommentTests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTest")
.protos({

test: function() {
this.TestCase("", "",        "-1000000000000000",        String( -1000000000000000 ) );

}

})
.endType();








