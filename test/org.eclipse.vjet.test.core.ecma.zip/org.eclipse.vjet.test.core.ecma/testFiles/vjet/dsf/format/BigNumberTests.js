vjo.ctype("vjet.dsf.format.BigNumberTests")
.inherits("vjet.dsf.jslang.feature.tests.BaseTest")
.protos({

test: function () {
var foo = -2208988800000;
}

})
.endType();
