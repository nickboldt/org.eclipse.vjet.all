vjo.ctype("vjet.dsf.jslang.feature.tests.ArrayWrapperTests")
.protos({

test_ArrayWrapper: function() {

var arrWrapper = [,,]; //< Integer[]

}

})
.endType();
